<!-- Emp No Field -->
<div class="form-group">
    {!! Form::label('emp_no', 'Emp No:') !!}
    <p>{!! $employees->emp_no !!}</p>
</div>

<!-- Birth Date Field -->
<div class="form-group">
    {!! Form::label('birth_date', 'Birth Date:') !!}
    <p>{!! $employees->birth_date !!}</p>
</div>

<!-- First Name Field -->
<div class="form-group">
    {!! Form::label('first_name', 'First Name:') !!}
    <p>{!! $employees->first_name !!}</p>
</div>

<!-- Last Name Field -->
<div class="form-group">
    {!! Form::label('last_name', 'Last Name:') !!}
    <p>{!! $employees->last_name !!}</p>
</div>

<!-- Gender Field -->
<div class="form-group">
    {!! Form::label('gender', 'Gender:') !!}
    <p>{!! $employees->gender !!}</p>
</div>

<!-- Hire Date Field -->
<div class="form-group">
    {!! Form::label('hire_date', 'Hire Date:') !!}
    <p>{!! $employees->hire_date !!}</p>
</div>

<!-- Deleted At Field -->
<div class="form-group">
    {!! Form::label('deleted_at', 'Deleted At:') !!}
    <p>{!! $employees->deleted_at !!}</p>
</div>

