<table class="table table-responsive" id="employees-table">
    <thead>
        <th>Birth Date</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Gender</th>
        <th>Hire Date</th>
        <th>Deleted At</th>
        <th colspan="3">Action</th>
    </thead>
    <tbody>
    @foreach($employees as $employees)
        <tr>
            <td>{!! $employees->birth_date !!}</td>
            <td>{!! $employees->first_name !!}</td>
            <td>{!! $employees->last_name !!}</td>
            <td>{!! $employees->gender !!}</td>
            <td>{!! $employees->hire_date !!}</td>
            <td>{!! $employees->deleted_at !!}</td>
            <td>
                {!! Form::open(['route' => ['employees.destroy', $employees->id], 'method' => 'delete']) !!}
                <div class='btn-group'>
                    <a href="{!! route('employees.show', [$employees->id]) !!}" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="{!! route('employees.edit', [$employees->id]) !!}" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    {!! Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]) !!}
                </div>
                {!! Form::close() !!}
            </td>
        </tr>
    @endforeach
    </tbody>
</table>