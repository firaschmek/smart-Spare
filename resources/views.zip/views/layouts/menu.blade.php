<li class="{{ Request::is('employees*') ? 'active' : '' }}">
    <a href="{!! route('employees.index') !!}"><i class="fa fa-edit"></i><span>employees</span></a>
</li>

<li class="{{ Request::is('employees*') ? 'active' : '' }}">
    <a href="{!! route('employees.index') !!}"><i class="fa fa-edit"></i><span>employees</span></a>
</li>

<li class="{{ Request::is('employees*') ? 'active' : '' }}">
    <a href="{!! route('employees.index') !!}"><i class="fa fa-edit"></i><span>employees</span></a>
</li>

<li class="{{ Request::is('salaries*') ? 'active' : '' }}">
    <a href="{!! route('salaries.index') !!}"><i class="fa fa-edit"></i><span>salaries</span></a>
</li>

<li class="{{ Request::is('users*') ? 'active' : '' }}">
    <a href="{!! route('users.index') !!}"><i class="fa fa-edit"></i><span>Users</span></a>
</li>

<li class="{{ Request::is('demos*') ? 'active' : '' }}">
    <a href="{!! route('demos.index') !!}"><i class="fa fa-edit"></i><span>Demos</span></a>
</li>

<li class="{{ Request::is('demos*') ? 'active' : '' }}">
    <a href="{!! route('demos.index') !!}"><i class="fa fa-edit"></i><span>Demos</span></a>
</li>

<li class="{{ Request::is('clients*') ? 'active' : '' }}">
    <a href="{!! route('clients.index') !!}"><i class="fa fa-edit"></i><span>Clients</span></a>
</li>

<li class="{{ Request::is('projets*') ? 'active' : '' }}">
    <a href="{!! route('projets.index') !!}"><i class="fa fa-edit"></i><span>Projets</span></a>
</li>

